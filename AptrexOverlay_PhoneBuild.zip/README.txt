APTREX OVERLAY - Android project

Features:
- Floating AF bubble shown above other apps.
- Tap bubble to show/hide the APTREX FARM MOD panel.
- Move the bubble by dragging it.
- All menu controls are visual ON/OFF switches only. They do not modify games,
  automate taps, change app behavior, or perform background actions.

Build on a computer:
Open this folder in Android Studio and build the debug APK.

Build using only your Android phone:
Follow BUILD_ON_PHONE.txt. A GitHub Actions workflow is included in
.github/workflows/build-apk.yml to compile the APK online.
