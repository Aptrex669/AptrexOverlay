package com.aptrex.overlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(12, 12, 16))
        }
        val title = TextView(this).apply {
            text = "APTREX OVERLAY"
            textSize = 26f
            setTextColor(Color.rgb(255, 55, 55))
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Floating menu with visual ON/OFF switches only. Allow display over other apps to use it."
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 24)
        }
        val allow = Button(this).apply {
            text = "Allow overlay permission"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else startOverlay()
            }
        }
        val start = Button(this).apply {
            text = "Start floating menu"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) startOverlay()
                else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
        root.addView(title)
        root.addView(info)
        root.addView(allow)
        root.addView(start)
        setContentView(root)
    }

    private fun startOverlay() {
        val i = Intent(this, OverlayService::class.java)
        startForegroundService(i)
        finish()
    }
}
