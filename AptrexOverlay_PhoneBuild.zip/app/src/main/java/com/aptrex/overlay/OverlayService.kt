package com.aptrex.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var expanded = false
    private val switches = mutableMapOf<String, Boolean>()

    override fun onCreate() {
        super.onCreate()
        startForeground(41, makeNotification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun makeNotification(): Notification {
        val channelId = "aptrex_overlay"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Aptrex floating overlay",
                NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val builder = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channelId) else Notification.Builder(this)
        return builder.setContentTitle("Aptrex Overlay is running")
            .setContentText("Tap the floating AF icon to open the visual menu")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
    }

    private fun params(width: Int, height: Int, gravity: Int = Gravity.TOP or Gravity.START) =
        WindowManager.LayoutParams(
            width, height,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { this.gravity = gravity }

    private fun bg(color: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun showBubble() {
        val b = TextView(this).apply {
            text = "AF"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(20, 45, 255))
                setStroke(dp(2), Color.rgb(0, 220, 255))
            }
            elevation = dp(8).toFloat()
        }
        val p = params(dp(54), dp(54)).apply { x = dp(12); y = dp(180) }
        b.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX; downY = e.rawY; startX = p.x; startY = p.y; moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - downX).toInt(); val dy = (e.rawY - downY).toInt()
                        if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > dp(5)) moved = true
                        p.x = startX + dx; p.y = startY + dy
                        wm.updateViewLayout(b, p)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) togglePanel()
                        return true
                    }
                }
                return true
            }
        })
        bubble = b
        wm.addView(b, p)
    }

    private fun togglePanel() {
        if (expanded) {
            panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            panel = null; expanded = false
        } else {
            showPanel(); expanded = true
        }
    }

    private fun showPanel() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = bg(Color.rgb(5, 5, 8), dp(16).toFloat()).also {
                it.setStroke(dp(2), Color.rgb(235, 45, 45))
            }
            elevation = dp(14).toFloat()
        }
        val heading = TextView(this).apply {
            text = "APTREX FARM MOD"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(255, 55, 55))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(12))
        }
        root.addView(heading)
        addSwitch(root, "COMPLETE ALL CHALLENGES")
        addSwitch(root, "INSTANT WIN")
        addSwitch(root, "AUTO STORY MODE")
        addSwitch(root, "AUTO EVENT MODE")
        addSwitch(root, "MAX SPEED")
        val close = TextView(this).apply {
            text = "CLOSE MENU"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(10), 0, 0)
            setOnClickListener { togglePanel() }
        }
        root.addView(close)
        val p = params(dp(310), WindowManager.LayoutParams.WRAP_CONTENT).apply {
            x = dp(12); y = dp(90)
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        }
        panelParams = p
        panel = root
        wm.addView(root, p)
    }

    private fun addSwitch(parent: LinearLayout, label: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(7), 0, dp(7))
        }
        val name = TextView(this).apply {
            text = label
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
            gravity = Gravity.CENTER_VERTICAL
        }
        val state = TextView(this).apply {
            text = "OFF"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = bg(Color.rgb(65, 65, 75), dp(8).toFloat())
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        switches[label] = false
        state.setOnClickListener {
            val enabled = !(switches[label] ?: false)
            switches[label] = enabled
            state.text = if (enabled) "ON" else "OFF"
            state.background = bg(if (enabled) Color.rgb(0, 205, 160) else Color.rgb(65, 65, 75), dp(8).toFloat())
            Toast.makeText(this, "$label: ${if (enabled) "ON" else "OFF"} (visual only)", Toast.LENGTH_SHORT).show()
        }
        row.addView(name)
        row.addView(state)
        parent.addView(row)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
